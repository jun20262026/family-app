<?php
/**
 * Message notification API
 * Get unread messages (new donations/expenses/transfers)
 * Mark messages as read
 */

require_once __DIR__ . '/../config.php';
$pdo = getDB();

// Check login
if (empty($_SESSION['user']['id'])) {
    echo json_encode(array('success' => false, 'msg' => 'Please login first'));
    exit;
}

$currentUserId = $_SESSION['user']['id'];
$currentRole = $_SESSION['user']['role'];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');

// 兼容 JSON 请求体（前端有时会用 JSON 格式发送）
if (empty($action)) {
    $rawInput = file_get_contents('php://input');
    if ($rawInput) {
        $input = json_decode($rawInput, true);
        if ($input && isset($input['action'])) {
            $action = $input['action'];
        }
    }
}

if ($action === 'get_unread') {
    // Get unread messages
    $stmt = $pdo->prepare('SELECT last_notification_check FROM users WHERE id = ?');
    $stmt->execute(array($currentUserId));
    $user = $stmt->fetch();
    $lastCheck = $user['last_notification_check'];

    $messages = array();

    if (!$lastCheck) {
        // First time - show recent announcements, then set check timestamp
        $stmt = $pdo->query('SELECT a.*, u.username as author_username FROM announcements a LEFT JOIN users u ON a.created_by = u.id ORDER BY a.is_visible DESC, a.created_at DESC LIMIT 5');
        $newAnns = $stmt->fetchAll();
        foreach ($newAnns as $a) {
            $author = $a['author_username'] ?: '未知';
            $isTopVal = intval($a['is_visible']) === 1;
            $messages[] = array(
                'type' => 'announcement',
                'icon' => $isTopVal ? '🔔' : '📢',
                'title' => ($isTopVal ? '[置顶]' : '') . '公告通知',
                'content' => mb_substr($a['title'], 0, 40) . (mb_strlen($a['title']) > 40 ? '...' : '') . ' — ' . $author,
                'time' => $a['created_at'],
                'link' => '#announcements'
            );
        }
        // Set last check so next time won't repeat
        $pdo->prepare('UPDATE users SET last_notification_check = NOW() WHERE id = ?')->execute(array($currentUserId));
        echo json_encode(array('success' => true, 'data' => $messages));
        exit;
    }

    // 2. Query new donation records after lastCheck
    $stmt = $pdo->prepare('
        SELECT *
        FROM donations
        WHERE created_at > ?
        ORDER BY created_at DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck));
    $newDonations = $stmt->fetchAll();

    foreach ($newDonations as $d) {
        $donorName = $d['donor_name'] ? $d['donor_name'] : '未知';
        $messages[] = array(
            'type' => 'donation',
            'icon' => '💰',
            'title' => '新的捐款记录',
            'content' => $donorName . ' 捐款 ¥' . number_format($d['amount'], 2),
            'time' => $d['created_at'],
            'link' => '#records'
        );
    }

    // 3. Query new expense records after lastCheck - 使用 trans_type 字段
    $stmt = $pdo->prepare('
        SELECT *
        FROM wallet_transactions
        WHERE trans_type = \'expense\' AND created_at > ?
        ORDER BY created_at DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck));
    $newExpenses = $stmt->fetchAll();

    foreach ($newExpenses as $e) {
        $desc = $e['description'] ? $e['description'] : '无描述';
        $messages[] = array(
            'type' => 'expense',
            'icon' => '💸',
            'title' => '新的支出记录',
            'content' => '支出 ¥' . number_format(abs($e['amount']), 2) . ' - ' . $desc,
            'time' => $e['created_at'],
            'link' => '#expense-records'
        );
    }

    // 4. Query new transfer records after lastCheck - 使用 trans_type 字段
    $stmt = $pdo->prepare('
        SELECT *
        FROM wallet_transactions
        WHERE trans_type = \'transfer\' AND created_at > ?
        ORDER BY created_at DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck));
    $newTransfers = $stmt->fetchAll();

    foreach ($newTransfers as $t) {
        $related = $t['related_name'] ? $t['related_name'] : '未知';
        $messages[] = array(
            'type' => 'transfer',
            'icon' => '🔄',
            'title' => '新的转账记录',
            'content' => '转账 ¥' . number_format(abs($t['amount']), 2) . ' 给 ' . $related,
            'time' => $t['created_at'],
            'link' => '#wallet'
        );
    }

    // 5. Query new or updated memos after lastCheck
    // 用 COALESCE 处理 updated_at 为 NULL 的情况
    $stmt = $pdo->prepare('
        SELECT m.*, u.username,
               COALESCE(m.updated_at, m.created_at) AS sort_time
        FROM memos m
        LEFT JOIN users u ON m.record_by = u.id
        WHERE m.created_at > ? OR (m.updated_at IS NOT NULL AND m.updated_at > ?)
        ORDER BY sort_time DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck, $lastCheck));
    $newMemos = $stmt->fetchAll();

    foreach ($newMemos as $m) {
        // 判断是否为更新：updated_at 存在且比 created_at 晚超过1秒
        $ua = $m['updated_at'] ?? null;
        $ca = $m['created_at'] ?? null;
        $isUpdate = ($ua && $ca && (abs(strtotime($ua) - strtotime($ca)) > 1));
        $byName = $m['record_by_name'] ?: $m['username'] ?: '未知';
        $messages[] = array(
            'type' => 'memo',
            'icon' => $isUpdate ? '✏️' : '📝',
            'title' => $isUpdate ? '备忘录已更新' : '新增备忘录',
            'content' => mb_substr($m['content'], 0, 60) . (mb_strlen($m['content']) > 60 ? '...' : '') . ' — ' . $byName,
            'time' => $ua ?: $ca,
            'link' => '#memos'
        );
    }

    // 6. Query new or updated announcements after lastCheck
    $stmt = $pdo->prepare('
        SELECT a.*, u.username as author_username
        FROM announcements a
        LEFT JOIN users u ON a.created_by = u.id
        WHERE a.created_at > ? OR (a.updated_at IS NOT NULL AND a.updated_at > ?)
        ORDER BY a.is_visible DESC, a.created_at DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck, $lastCheck));
    $newAnns = $stmt->fetchAll();

    foreach ($newAnns as $a) {
        $ua2 = $a['updated_at'] ?? null;
        $ca2 = $a['created_at'] ?? null;
        $isUpdate2 = ($ua2 && $ca2 && (abs(strtotime($ua2) - strtotime($ca2)) > 1));
        $author = $a['author_name'] ?: $a['author_username'] ?: '未知';
        $isTopVal = intval($a['is_visible']) === 1;
        $messages[] = array(
            'type' => 'announcement',
            'icon' => $isTopVal ? '🔔' : ($isUpdate2 ? '✏️' : '📢'),
            'title' => ($isTopVal ? '[置顶]' : '') . ($isUpdate2 ? '公告已更新' : '新公告发布'),
            'content' => mb_substr($a['title'], 0, 40) . (mb_strlen($a['title']) > 40 ? '...' : '') . ' — ' . $author,
            'time' => $ua2 ?: $ca2,
            'link' => '#announcements'
        );
    }

    // 7. Query new plans after lastCheck
    $stmt = $pdo->prepare('
        SELECT p.*, u.username as creator_name
        FROM family_plans p
        LEFT JOIN users u ON p.created_by = u.id
        WHERE p.created_at > ?
        ORDER BY p.created_at DESC
        LIMIT 50
    ');
    $stmt->execute(array($lastCheck));
    $newPlans = $stmt->fetchAll();

    foreach ($newPlans as $p) {
        $creator = $p['creator_name'] ?: '未知';
        $messages[] = array(
            'type' => 'plan',
            'icon' => '📅',
            'title' => '新增家庭计划',
            'content' => mb_substr($p['title'], 0, 40) . (mb_strlen($p['title']) > 40 ? '...' : '') . ' — ' . $creator,
            'time' => $p['created_at'],
            'link' => '#plans'
        );
    }

    // Sort by time (newest first)
    usort($messages, function($a, $b) {
        return strtotime($b['time']) - strtotime($a['time']);
    });

    echo json_encode(array('success' => true, 'data' => $messages));
    exit;

} elseif ($action === 'mark_read') {
    // Mark as read
    $stmt = $pdo->prepare('UPDATE users SET last_notification_check = NOW() WHERE id = ?');
    $stmt->execute(array($currentUserId));
    echo json_encode(array('success' => true, 'msg' => 'Marked as read'));
    exit;

} else {
    echo json_encode(array('success' => false, 'msg' => 'Unknown action'));
    exit;
}
