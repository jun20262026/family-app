<?php
/**
 * 家庭计划 API
 * 所有用户可新增/同意，创建者或管理员可编辑/删除，执行人字段
 * 同意人：所有用户可点"同意"，再次点击取消同意
 */
require_once __DIR__ . '/../config.php';
requireLogin();

$action = $_GET['action'] ?? '';
$pdo = getDB();
$currentUserId = CURRENT_USER_ID();
$currentRole = CURRENT_ROLE();

try {

// ===== list: 计划列表 =====
if ($action === 'list') {
    // 先取用户映射表（id → brother_name）
    $uStmt = $pdo->query('SELECT id, IFNULL(brother_name, username) as display_name FROM users');
    $userMap = [];
    foreach ($uStmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
        $userMap[$u['id']] = $u['display_name'];
    }

    $stmt = $pdo->query(
        'SELECT p.*, u.username as creator_name'
        . ' FROM family_plans p'
        . ' LEFT JOIN users u ON p.created_by = u.id'
        . ' ORDER BY p.is_done ASC, p.plan_date DESC, p.created_at DESC'
    );
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // 解析同意人列表，并转为姓名数组
    foreach ($list as &$item) {
        $ids = $item['agree_users'] ? json_decode($item['agree_users'], true) : [];
        $item['agree_users'] = $ids;
        $item['agree_names'] = [];
        foreach ($ids as $uid) {
            $item['agree_names'][] = $userMap[$uid] ?? '用户' . $uid;
        }
    }
    jsonResponse(['success' => true, 'data' => $list]);
    exit;

// ===== create: 新增计划 =====
} elseif ($action === 'create') {
    $title      = trim($_POST['title'] ?? '');
    $planDate   = $_POST['plan_date'] ?? '';
    $planAmount = $_POST['plan_amount'] ?? '';
    $executor   = trim($_POST['executor'] ?? '');

    if (empty($title)) {
        jsonResponse(['success' => false, 'error' => '请输入计划事项']);
    }

    $stmt = $pdo->prepare('INSERT INTO family_plans (title, plan_date, plan_amount, executor, created_by) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$title, $planDate ?: null, $planAmount ?: null, $executor ?: null, $currentUserId]);

    logAction($currentUserId, '新增家庭计划', '计划：' . $title);
    jsonResponse(['success' => true, 'msg' => '计划已添加']);

// ===== update: 修改计划 =====
} elseif ($action === 'update') {
    $id          = $_POST['id'] ?? '';
    $title       = trim($_POST['title'] ?? '');
    $planDate    = $_POST['plan_date'] ?? '';
    $planAmount  = $_POST['plan_amount'] ?? '';
    $executor    = trim($_POST['executor'] ?? '');

    if (empty($id) || empty($title)) {
        jsonResponse(['success' => false, 'error' => '参数错误']);
    }

    // 验证权限：创建者或管理员
    $stmt = $pdo->prepare('SELECT created_by FROM family_plans WHERE id = ?');
    $stmt->execute([$id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$plan) {
        jsonResponse(['success' => false, 'error' => '计划不存在']);
    }
    if ($currentRole !== 'admin' && $plan['created_by'] != $currentUserId) {
        jsonResponse(['success' => false, 'error' => '无权限修改此计划']);
    }

    $stmt2 = $pdo->prepare('UPDATE family_plans SET title = ?, plan_date = ?, plan_amount = ?, executor = ?, updated_at = NOW() WHERE id = ?');
    $stmt2->execute([$title, $planDate ?: null, $planAmount ?: null, $executor ?: null, $id]);

    logAction($currentUserId, '修改家庭计划', '计划ID：' . $id);
    jsonResponse(['success' => true, 'msg' => '计划已修改']);

// ===== delete: 删除计划 =====
} elseif ($action === 'delete') {
    $id = $_POST['id'] ?? '';
    if (empty($id)) {
        jsonResponse(['success' => false, 'error' => '参数错误']);
    }

    $stmt = $pdo->prepare('SELECT created_by FROM family_plans WHERE id = ?');
    $stmt->execute([$id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$plan) {
        jsonResponse(['success' => false, 'error' => '计划不存在']);
    }
    if ($currentRole !== 'admin' && $plan['created_by'] != $currentUserId) {
        jsonResponse(['success' => false, 'error' => '无权限删除此计划']);
    }

    $stmt2 = $pdo->prepare('DELETE FROM family_plans WHERE id = ?');
    $stmt2->execute([$id]);

    logAction($currentUserId, '删除家庭计划', '计划ID：' . $id);
    jsonResponse(['success' => true, 'msg' => '计划已删除']);

// ===== toggle_done: 标记完成/重新打开 =====
} elseif ($action === 'toggle_done') {
    $id = $_POST['id'] ?? '';
    if (empty($id)) {
        jsonResponse(['success' => false, 'error' => '参数错误']);
    }

    $stmt = $pdo->prepare('UPDATE family_plans SET is_done = NOT is_done WHERE id = ?');
    $stmt->execute([$id]);

    logAction($currentUserId, '切换计划完成状态', '计划ID：' . $id);
    jsonResponse(['success' => true, 'msg' => '操作成功']);

// ===== toggle_agree: 同意/取消同意 =====
} elseif ($action === 'toggle_agree') {
    $id = $_POST['id'] ?? '';
    if (empty($id)) {
        jsonResponse(['success' => false, 'error' => '参数错误']);
    }

    // 获取当前同意人列表
    $stmt = $pdo->prepare('SELECT agree_users FROM family_plans WHERE id = ?');
    $stmt->execute([$id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$plan) {
        jsonResponse(['success' => false, 'error' => '计划不存在']);
    }

    $agreeList = $plan['agree_users'] ? json_decode($plan['agree_users'], true) : [];
    $idx = array_search($currentUserId, $agreeList);
    if ($idx !== false) {
        // 已同意 → 取消同意
        array_splice($agreeList, $idx, 1);
    } else {
        // 未同意 → 添加同意
        $agreeList[] = $currentUserId;
    }
    $agreeJson = json_encode(array_values($agreeList));

    $stmt2 = $pdo->prepare('UPDATE family_plans SET agree_users = ? WHERE id = ?');
    $stmt2->execute([$agreeJson, $id]);

    jsonResponse(['success' => true, 'msg' => '操作成功']);
}

} catch (PDOException $e) {
    error_log('[plans] PDO Error: ' . $e->getMessage());
    jsonResponse(['success' => false, 'error' => '数据库错误：' . $e->getMessage()]);
} catch (Exception $e) {
    error_log('[plans] Error: ' . $e->getMessage());
    jsonResponse(['success' => false, 'error' => '操作出错：' . $e->getMessage()]);
}
